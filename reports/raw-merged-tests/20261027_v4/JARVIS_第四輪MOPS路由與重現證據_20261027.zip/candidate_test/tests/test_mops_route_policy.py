import unittest,json,pathlib
from scripts.v093_mops_route_policy import plan_route
class RoutePolicy(unittest.TestCase):
 def call(self,y=2001,q=1,m='TWSE',**kw):return plan_route(y,q,m,as_of='2026-10-27',**kw)
 def proof(self,y):return {'year':y,'approved':True,'reference':'SYNTHETIC reviewed evidence','sha256':'a'*64}
 def test_2001_twse_never_sent_to_compare_by_default(self):self.assertFalse(self.call()['request_allowed'])
 def test_2012_tpex_requires_legacy_route(self):self.assertEqual(self.call(2012,4,'TPEx')['action'],'LEGACY_ROUTE_RESEARCH_REQUIRED')
 def test_public_2014_not_assumed_ifrs(self):self.assertEqual(self.call(2014,4,'PUBLIC')['action'],'LEGACY_ROUTE_RESEARCH_REQUIRED')
 def test_emerging_2012_not_assumed_ifrs(self):self.assertFalse(self.call(2012,2,'EMERGING')['request_allowed'])
 def test_2013_still_requires_company_adoption(self):self.assertEqual(self.call(2013)['action'],'VERIFY_COMPANY_ADOPTION_BEFORE_COMPARE')
 def test_documented_late_adopter_blocks_earlier_period(self):self.assertEqual(self.call(2013,adoption=self.proof(2018))['action'],'PRE_ADOPTION_LEGACY_ROUTE_REQUIRED')
 def test_documented_exception_is_not_globally_disallowed(self):self.assertTrue(self.call(2001,adoption=self.proof(2000))['request_allowed'])
 def test_approved_2013_is_canary_not_certified(self):
  r=self.call(2013,adoption=self.proof(2013));self.assertTrue(r['request_allowed']);self.assertFalse(r['certified']);self.assertTrue(r['gap_remains_open'])
 def test_unapproved_adoption_claim_rejected(self):
  p=self.proof(2013);p['approved']=False
  with self.assertRaises(ValueError):self.call(2013,adoption=p)
 def test_invalid_quarter_rejected(self):
  with self.assertRaises(ValueError):self.call(q=5)
 def test_invalid_year_rejected(self):
  with self.assertRaises(ValueError):self.call(1999)
 def test_unknown_market_rejected(self):
  with self.assertRaises(ValueError):self.call(m='UNKNOWN')
 def test_future_period_not_due(self):self.assertEqual(self.call(2026,4)['action'],'PERIOD_NOT_DUE')
 def test_noncalendar_year_requires_review(self):self.assertEqual(self.call(2025,calendar_type='NONCALENDAR')['action'],'CONFIRM_FISCAL_PERIOD')
 def test_route_gap_and_attempts_are_preserved(self):
  r=self.call();self.assertTrue(r['gap_remains_open']);self.assertTrue(r['attempts_preserved']);self.assertIsNone(r['route'])
 def test_emerging_q1_not_assumed_required(self):self.assertEqual(self.call(2025,1,'EMERGING',adoption=self.proof(2013))['action'],'VERIFY_REPORTING_QUARTER_APPLICABILITY')
 def test_public_q3_not_assumed_required(self):self.assertEqual(self.call(2025,3,'PUBLIC',adoption=self.proof(2015))['action'],'VERIFY_REPORTING_QUARTER_APPLICABILITY')
class RealMopsComparison(unittest.TestCase):
 def test_retained_2001_is_header_only(self):
  from lxml import html
  p=pathlib.Path(__file__).resolve().parents[2]/'real_sample/raw/MOPS.raw';d=html.fromstring(p.read_text(encoding='utf-8-sig'));self.assertEqual(len(d.xpath('//tr')),4)
 def test_2013_2025_containers_and_raw_match(self):
  import hashlib,zipfile
  root=pathlib.Path(__file__).resolve().parents[2];rows=json.load(open(root/'mops_year_samples.json'))
  for x in rows:
   if x['月份'].startswith('2001'):continue
   raw=(root/'mops_route_review/raw'/(x['月份']+'.raw')).read_bytes();self.assertEqual(hashlib.sha256(raw).hexdigest(),x['RAW_SHA256'])
   with zipfile.ZipFile(root/'mops_route_review/containers'/(x['月份']+'.zip')) as z:self.assertIsNone(z.testzip())
 def test_pre2013_backlog_keeps_exact_record_count(self):
  import csv
  root=pathlib.Path(__file__).resolve().parents[2]
  with open(root/'mops_route_review/pre2013_compare_tasks.csv',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
  self.assertEqual(len(rows),6965);self.assertTrue(all(int(r['期間'][:4])<2013 for r in rows));self.assertTrue(all(r['查詢URL']=='https://mopsfin.twse.com.tw/compare/report' for r in rows))
 def test_later_year_controls_have_numeric_content(self):
  import re
  from lxml import html
  root=pathlib.Path(__file__).resolve().parents[2]
  for m in ['2013-09','2025-09']:
   d=html.fromstring((root/'mops_route_review/raw'/(m+'.raw')).read_text(encoding='utf-8-sig'));values=[' '.join(x.text_content().split()) for x in d.xpath('//td|//th')]
   self.assertGreater(sum(bool(re.fullmatch(r'[+-]?[0-9,]+(?:\.[0-9]+)?',x)) for x in values),100)
