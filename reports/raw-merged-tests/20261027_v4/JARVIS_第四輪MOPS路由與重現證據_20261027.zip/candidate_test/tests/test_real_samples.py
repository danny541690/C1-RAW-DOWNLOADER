import unittest,pathlib,json,hashlib,zipfile
from scripts.v093_official_content_audit import audit_rows
from scripts.v093_ndc_independent import parse_bundle,month_payload
from scripts.v093_tdcc_independent import validate_history
R=pathlib.Path(__file__).resolve().parents[2]/'real_sample'
C={x['來源']:x for x in json.load(open(R.parent/'sample_candidates.json'))}
class StoredRawReadback(unittest.TestCase):pass
for source in C:
 def check(self,source=source):
  raw=(R/'raw'/f'{source}.raw').read_bytes();self.assertEqual(hashlib.sha256(raw).hexdigest(),C[source]['RAW_SHA256'])
 setattr(StoredRawReadback,'test_'+source+'_ledger_sha',check)
class NativeArchiveChecks(unittest.TestCase):
 def test_ndc_native_archive_and_derived_cells(self):
  d=json.loads((R/'raw/NDC.raw').read_bytes());b=(R/'containers/NDC_SOURCE.xlsx').read_bytes();self.assertEqual(hashlib.sha256(b).hexdigest(),d['source_archive']['sha256']);regen=month_payload(parse_bundle(b),d['month'],d['source_archive']);self.assertEqual(regen['tables'],d['tables']);self.assertEqual(regen['gaps'],d['gaps'])
 def test_tdcc_real_result_date_and_code(self):self.assertGreater(validate_history((R/'raw/TDCC.raw').read_bytes(),'20251031','000218'),0)
 def test_mops_missing_pit_is_not_promoted(self):
  from scripts.v093_source_pit_unit_evidence import mops_html_evidence
  x=mops_html_evidence((R/'raw/MOPS.raw').read_text(encoding='utf-8-sig'));self.assertFalse(x['pit_verified']);self.assertFalse(x['certified'])
for source in ['FinMind','MOPS','TWSE','TPEx','TAIFEX','NDC_SOURCE']:
 def check(self,source=source):
  p=R/'containers'/('NDC_SOURCE.xlsx' if source=='NDC_SOURCE' else source+'.bin')
  with zipfile.ZipFile(p) as z:self.assertIsNone(z.testzip())
 setattr(NativeArchiveChecks,'test_'+source+'_crc',check)
class RealMarginCoverage(unittest.TestCase):
 def test_twse_real_margin_numeric_fields_are_checked(self):
  x=audit_rows((R/'raw/TWSE.raw').read_bytes(),{'source':'TWSE','category':'margin'});self.assertGreater(x['numeric_cells_checked'],0)
 def test_tpex_real_margin_numeric_fields_are_checked(self):
  x=audit_rows((R/'raw/TPEx.raw').read_bytes(),{'source':'TPEx','category':'margin'});self.assertGreater(x['numeric_cells_checked'],0)
class MarginNumericBoundaries(unittest.TestCase):
 def payload(self):return json.loads((R/'raw/TPEx.raw').read_bytes())
 def test_negative_margin_buy_quantity_rejected(self):
  d=self.payload();d['tables'][0]['data'][0][3]='-1'
  with self.assertRaisesRegex(ValueError,'NEGATIVE_NONNEGATIVE_FIELD'):audit_rows(json.dumps(d).encode(),{'source':'TPEx','category':'margin'})
 def test_native_usage_percent_suffix_is_parsed(self):
  d=self.payload();d['tables'][0]['data'][0][8]='41.67%';x=audit_rows(json.dumps(d).encode(),{'source':'TPEx','category':'margin'});self.assertGreater(x['numeric_cells_checked'],0)
 def test_missing_margin_value_stays_unverified(self):
  d=self.payload();d['tables'][0]['data'][0][3]='--';x=audit_rows(json.dumps(d).encode(),{'source':'TPEx','category':'margin'});self.assertIn('MISSING_NUMERIC_CELL',x['unverified'])
 def test_margin_does_not_claim_unperformed_ohlc(self):
  x=audit_rows((R/'raw/TWSE.raw').read_bytes(),{'source':'TWSE','category':'margin'});self.assertNotIn('OHLC_RELATIONSHIPS',x['checks'])
 def test_numeric_checks_do_not_imply_full_margin_acceptance(self):
  x=audit_rows((R/'raw/TPEx.raw').read_bytes(),{'source':'TPEx','category':'margin'});self.assertIn('MARGIN_ACCOUNTING_AND_FULL_SCOPE_NOT_PROVEN',x['unverified']);self.assertFalse(x['pit_verified'])
