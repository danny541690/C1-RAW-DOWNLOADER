import json,pathlib,decimal,collections
D=decimal.Decimal
out={}
for src in ['TWSE','TPEx']:
 d=json.loads(pathlib.Path('real_sample/raw',src+'.raw').read_bytes());bad=[];checked=0;cells=0
 for ti,t in enumerate(d['tables']):
  fields=t['fields']
  if src=='TWSE' and fields==['代號','名稱','買進','賣出','現金償還','前日餘額','今日餘額','次一營業日限額','買進','賣出','現券償還','前日餘額','今日餘額','次一營業日限額','資券互抵','註記']:
   ranges=[(6,5,2,3,4,'margin'),(12,11,9,8,10,'short')]
  elif src=='TPEx' and fields[:7]==['代號','名稱','前資餘額(張)','資買','資賣','現償','資餘額'] and fields[10:15]==['前券餘額(張)','券賣','券買','券償','券餘額']:
   ranges=[(6,2,3,4,5,'margin'),(14,10,11,12,13,'short')]
  else:continue
  for row in t['data']:
   for today,prior,inflow,outflow,repay,kind in ranges:
    try:v={i:D(row[i].replace(',','')) for i in [today,prior,inflow,outflow,repay]}
    except decimal.InvalidOperation:bad.append({'code':row[0],'kind':kind,'status':'MISSING_OR_NONNUMERIC'});continue
    checked+=1;cells+=len(v);delta=v[today]-(v[prior]+v[inflow]-v[outflow]-v[repay])
    if delta:bad.append({'code':row[0],'kind':kind,'delta_native_units':str(delta),'status':'NEEDS_SOURCE_ADJUSTMENT_REVIEW'})
 out[src]={'relationships_checked':checked,'numeric_cells_used_with_repetition':cells,'nonzero_or_missing_relationships':bad,'scope':'Supplementary diagnostic, not acceptance: adjustments and historical field semantics still need review'}
pathlib.Path('real_sample/margin_probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print({k:{'relationships':v['relationships_checked'],'review_items':len(v['nonzero_or_missing_relationships'])} for k,v in out.items()})
