import unittest,json,tempfile,pathlib,csv,gzip,hashlib
from scripts.v093_official_content_audit import audit_rows
from scripts import register_baseline as r
class CoverageRegression(unittest.TestCase):
 def test_mixed_leading_zero_security_cannot_silently_pass(self):
  raw=json.dumps({'fields':['證券代號','開盤價','最高價','最低價','收盤價'],'data':[['2330','100','110','90','105'],['0050','100','50','40','45']]}).encode()
  try:x=audit_rows(raw,{'source':'TWSE','category':'prices'})
  except ValueError:return
  self.assertTrue(x['unverified'] or x['ohlc_rows_checked']==2,'Applicable leading-zero row silently skipped without unverified marker')
class RepairEvents(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.old=r.ROOT;r.ROOT=pathlib.Path(self.temp.name);(r.ROOT/'units').mkdir()
  with open(r.ROOT/'repair_events.csv','w',encoding='utf-8-sig',newline='') as f:csv.writer(f).writerow(r.HEAD)
  u={'任務ID':'fixture_task','單元ID':'fixture_unit','來源':'TWSE','月份':'2026-01','RAW_SHA256':'','已下載':'0','明列品質問題':'0'}
  with gzip.open(r.ROOT/'units/TWSE_units.csv.gz','wt',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(u));w.writeheader();w.writerow(u)
  self.p=dict(task_id='fixture_task',unit_id='fixture_unit',source='TWSE',month='2026-01',event_type='VERIFIED',event_time='2026-10-27T10:00:00+08:00',reason='SYNTHETIC fixture',reviewer='test',new_sha256='a'*64,new_file_ref='fixture://nonexistent/raw',run_url='fixture://nonexistent/run',remote_hash_verified=True,period_verified=True,security_verified=True,numeric_verified=True,pit_verified=True,unit_scope_verified=True,unfilled_count=0)
 def approve(self):
  raw=b'SYNTHETIC: accepted evidence integrity fixture, not market validation';(r.ROOT/'raw.bin').write_bytes(raw)
  self.p.update(new_sha256=hashlib.sha256(raw).hexdigest(),validation_receipt_id='receipt-1')
  evidence={k:self.p[k] for k in ['task_id','unit_id','source','month','new_file_ref','new_sha256','run_url']}
  keys=['PERIOD','SECURITY','NUMERIC','PIT','UNIT_SCOPE']
  evidence.update(bytes=len(raw),remote_readback_sha256=self.p['new_sha256'],validator_version='synthetic-v1',universe_version='synthetic-universe',status='PASS',coverage_complete=True,missing_count=0,unknown_count=0,conflict_count=0,rule_results={k:'PASS' for k in keys})
  self.evidence=evidence;self.approval=dict(approved=True,approved_by='synthetic-reviewer',approved_at='2026-10-27T09:00:00+08:00',validator_version='synthetic-v1',artifact_path='validation.json',raw_local_path='raw.bin',required_rules=keys)
  self.save_evidence()
 def save_evidence(self):
  data=json.dumps(self.evidence,sort_keys=True).encode();(r.ROOT/'validation.json').write_bytes(data);self.approval['artifact_sha256']=hashlib.sha256(data).hexdigest();(r.ROOT/'approved_validation_receipts.json').write_text(json.dumps({'receipt-1':self.approval}))
 def tearDown(self):r.ROOT=self.old;self.temp.cleanup()
 def test_bool_claim_without_actual_evidence_is_rejected(self):
  with self.assertRaises(ValueError,msg='VERIFIED must reject nonexistent RAW/validator evidence even if bools are true'):r.record(self.p)
 def test_close_requires_preceding_verified(self):
  self.approve();self.p['event_type']='CLOSED'
  with self.assertRaisesRegex(ValueError,'preceding|requires VERIFIED'):r.record(self.p)
 def test_replay_is_idempotent(self):
  self.approve();r.record(self.p);self.assertEqual(r.record(self.p)['status'],'already_recorded');self.assertEqual(len(r.events()),1)
 def test_reopen_preserves_downloaded_fact(self):
  self.approve();r.record(self.p);self.p['event_type']='CLOSED';r.record(self.p);self.assertEqual(r.rebuild()['closed'],1);self.p['event_type']='REOPENED';r.record(self.p);self.assertEqual(r.rebuild()['closed'],0)
  u=next(csv.DictReader(open(r.ROOT/'current_monthly.csv',encoding='utf-8-sig')));self.assertEqual(u['已下載'],'1');self.assertEqual(u['明列品質問題'],'1')

 def test_reject_wrong_task(self):
  self.approve();self.evidence['task_id']='another';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_wrong_source(self):
  self.approve();self.evidence['source']='MOPS';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_wrong_month(self):
  self.approve();self.evidence['month']='2025-01';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_wrong_unit(self):
  self.approve();self.evidence['unit_id']='other';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_wrong_raw_ref(self):
  self.approve();self.evidence['new_file_ref']='other';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_wrong_run(self):
  self.approve();self.evidence['run_url']='other';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_wrong_readback_sha(self):
  self.approve();self.evidence['remote_readback_sha256']='b'*64;self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_wrong_byte_count(self):
  self.approve();self.evidence['bytes']+=1;self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_partial_coverage(self):
  self.approve();self.evidence['coverage_complete']=False;self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_unknown_findings(self):
  self.approve();self.evidence['unknown_count']=1;self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_string_zero_count(self):
  self.approve();self.evidence['missing_count']='0';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_boolean_zero_count(self):
  self.approve();self.evidence['conflict_count']=False;self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_failed_rule(self):
  self.approve();self.evidence['rule_results']['PIT']='FAIL';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_missing_rule(self):
  self.approve();del self.evidence['rule_results']['NUMERIC'];self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_unapproved_receipt(self):
  self.approve();self.approval['approved']=False;self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_missing_rule_contract(self):
  self.approve();self.approval['required_rules']=[];self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_missing_acceptance_dimension(self):
  self.approve();self.approval['required_rules']=['PIT'];self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_missing_universe(self):
  self.approve();self.evidence['universe_version']='';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_future_approval(self):
  self.approve();self.approval['approved_at']='2026-10-28T09:00:00+08:00';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_reject_naive_approval_time(self):
  self.approve();self.approval['approved_at']='2026-10-27T09:00:00';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)
  self.assertEqual(r.events(),[])

 def test_artifact_tamper_after_approval_rejected(self):
  self.approve();(r.ROOT/'validation.json').write_text('{}')
  with self.assertRaises(ValueError):r.record(self.p)
 def test_raw_tamper_after_validation_rejected(self):
  self.approve();(r.ROOT/'raw.bin').write_bytes(b'changed')
  with self.assertRaises(ValueError):r.record(self.p)
 def test_closed_cannot_switch_approved_evidence(self):
  self.approve();r.record(self.p);self.evidence['extra_note']='new revision';self.save_evidence();self.p['event_type']='CLOSED'
  with self.assertRaisesRegex(ValueError,'evidence differs'):r.record(self.p)
  self.assertEqual(len(r.events()),1)
 def test_old_journal_schema_rejected_without_writing(self):
  self.approve()
  with open(r.ROOT/'repair_events.csv','w',encoding='utf-8-sig',newline='') as f:csv.writer(f).writerow(r.HEAD[:-2])
  before=(r.ROOT/'repair_events.csv').read_bytes()
  with self.assertRaisesRegex(ValueError,'schema upgrade'):r.record(self.p)
  self.assertEqual(before,(r.ROOT/'repair_events.csv').read_bytes())
 def test_evidence_paths_cannot_escape_root(self):
  self.approve();self.approval['raw_local_path']='../outside.bin';self.save_evidence()
  with self.assertRaises(ValueError):r.record(self.p)

 def test_invalid_artifact_shape_rejected(self):
  self.approve();data=b'[]';(r.ROOT/'validation.json').write_bytes(data);self.approval['artifact_sha256']=hashlib.sha256(data).hexdigest();(r.ROOT/'approved_validation_receipts.json').write_text(json.dumps({'receipt-1':self.approval}))
  with self.assertRaisesRegex(ValueError,'Invalid validator artifact'):r.record(self.p)
 def test_invalid_registry_shape_rejected(self):
  self.approve();(r.ROOT/'approved_validation_receipts.json').write_text('[]')
  with self.assertRaisesRegex(ValueError,'Invalid approval registry'):r.record(self.p)

class SecurityScopeBoundaries(unittest.TestCase):
 def raw(self,code,valid=True):
  return json.dumps({'fields':['證券代號','開盤價','最高價','最低價','收盤價'],'data':[['2330','100','110','90','105'],[code,'100','110' if valid else '50','90' if valid else '40','105' if valid else '45']]}).encode()
 def test_unscoped_leading_zero_is_explicitly_unverified(self):
  x=audit_rows(self.raw('0050'),{'source':'TWSE','category':'prices'});self.assertIn('OHLC_SECURITY_OUTSIDE_VALIDATED_SCOPE',x['unverified']);self.assertEqual(x['ohlc_rows_checked'],1)
 def test_scoped_leading_zero_valid_rows_checked(self):
  x=audit_rows(self.raw('0050'),{'source':'TWSE','category':'prices','applicable_security_codes':['2330','0050']});self.assertEqual(x['ohlc_rows_checked'],2)
 def test_scoped_leading_zero_invalid_rows_rejected(self):
  with self.assertRaisesRegex(ValueError,'OHLC_RELATIONSHIP'):audit_rows(self.raw('0050',False),{'source':'TWSE','category':'prices','applicable_security_codes':['2330','0050']})
 def test_six_character_code_not_silently_skipped(self):
  x=audit_rows(self.raw('010001'),{'source':'TPEx','category':'prices'});self.assertTrue(x['unverified'])
 def test_numeric_scope_would_lose_zero_and_is_rejected(self):
  with self.assertRaisesRegex(ValueError,'INVALID_SECURITY_SCOPE'):audit_rows(self.raw('0050'),{'source':'TWSE','category':'prices','applicable_security_codes':[2330,50]})
