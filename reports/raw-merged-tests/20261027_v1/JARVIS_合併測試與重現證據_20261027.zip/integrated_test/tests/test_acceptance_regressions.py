import unittest,json,tempfile,pathlib,csv,gzip
from scripts.v093_official_content_audit import audit_rows
from scripts import register_baseline as r
class CoverageRegression(unittest.TestCase):
 def test_mixed_leading_zero_security_cannot_silently_pass(self):
  raw=json.dumps({'fields':['證券代號','開盤價','最高價','最低價','收盤價'],'data':[['2330','100','110','90','105'],['0050','100','50','40','45']]}).encode()
  try:x=audit_rows(raw,{'source':'TWSE','category':'prices'})
  except ValueError:return
  self.assertTrue(x['unverified'] or x['ohlc_rows_checked']==2,'Applicable leading-zero row silently skipped without unverified marker')
class RepairEvents(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.old=r.ROOT;r.ROOT=pathlib.Path(self.temp.name);(r.ROOT/'units').mkdir()
  with open(r.ROOT/'repair_events.csv','w',encoding='utf-8-sig',newline='') as f:csv.writer(f).writerow(r.HEAD)
  u={'任務ID':'fixture_task','單元ID':'fixture_unit','來源':'TWSE','月份':'2026-01','RAW_SHA256':'','已下載':'0','明列品質問題':'0'}
  with gzip.open(r.ROOT/'units/TWSE_units.csv.gz','wt',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(u));w.writeheader();w.writerow(u)
  self.p=dict(task_id='fixture_task',unit_id='fixture_unit',source='TWSE',month='2026-01',event_type='VERIFIED',event_time='2026-10-27T10:00:00+08:00',reason='SYNTHETIC fixture',reviewer='test',new_sha256='a'*64,new_file_ref='fixture://nonexistent/raw',run_url='fixture://nonexistent/run',remote_hash_verified=True,period_verified=True,security_verified=True,numeric_verified=True,pit_verified=True,unit_scope_verified=True,unfilled_count=0)
 def tearDown(self):r.ROOT=self.old;self.temp.cleanup()
 def test_bool_claim_without_actual_evidence_is_rejected(self):
  with self.assertRaises(ValueError,msg='VERIFIED must reject nonexistent RAW/validator evidence even if bools are true'):r.record(self.p)
 def test_close_requires_preceding_verified(self):
  self.p['event_type']='CLOSED'
  with self.assertRaises(ValueError):r.record(self.p)
 def test_replay_is_idempotent(self):
  r.record(self.p);self.assertEqual(r.record(self.p)['status'],'already_recorded');self.assertEqual(len(r.events()),1)
 def test_reopen_preserves_downloaded_fact(self):
  r.record(self.p);self.p['event_type']='CLOSED';r.record(self.p);self.assertEqual(r.rebuild()['closed'],1);self.p['event_type']='REOPENED';r.record(self.p);self.assertEqual(r.rebuild()['closed'],0)
  u=next(csv.DictReader(open(r.ROOT/'current_monthly.csv',encoding='utf-8-sig')));self.assertEqual(u['已下載'],'1');self.assertEqual(u['明列品質問題'],'1')
