import sys,pathlib,json,csv,zipfile,io,re,hashlib,collections,datetime,decimal,gzip
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'candidate_test'))
from scripts.v093_official_content_audit import audit_rows
from scripts.v093_source_pit_unit_evidence import mops_html_evidence
from scripts.v093_tdcc_independent import validate_history
from scripts.v093_taifex_independent import validate
from scripts.v093_ndc_independent import parse_bundle,month_payload
from scripts.v093_independent_raw import classify_finmind_price_payload
from lxml import html
C=json.load(open(ROOT/'sample_candidates.json'));results=[]
for c in C:
 src=c['來源'];b=(ROOT/'real_sample/raw'/f'{src}.raw').read_bytes();o={'source':src,'task_id':c['任務ID'],'unit_id':c['單元ID'],'dataset':c['資料集'],'ledger_period':c['期間'],'sha_match':hashlib.sha256(b).hexdigest()==c['RAW_SHA256'],'status':'UNKNOWN','pit_status':'UNKNOWN','scope':'single non-random saved sample; not source/database acceptance'}
 try:
  if src=='FinMind':
   d=json.loads(b);rows=d['data'];dates=[x['date'] for x in rows];codes={x['stock_id'] for x in rows};bad=[]
   for x in rows:
    vals=[decimal.Decimal(str(x[k])) for k in ['open','max','min','close']]
    if not all(v.is_finite() for v in vals) or not vals[2]<=vals[0]<=vals[1] or not vals[2]<=vals[3]<=vals[1]:bad.append(x['date'])
   o.update(rows=len(rows),content_period={'min':min(dates),'max':max(dates)},codes=sorted(codes),date_identity_pass=all(d.startswith(c['月份']) for d in dates) and codes=={c['代碼']},ohlc_violations=bad,parser_result=classify_finmind_price_payload(b),status='LIMITED_CHECK_PASS',unknown=['full trading-day universe','numeric fields beyond OHLC','native units and PIT'])
  elif src in ['TWSE','TPEx']:
   d=json.loads(b);tables=d['tables'];shape=[{'table':i,'fields':len(t.get('fields',[])),'rows':len(t.get('data',[])),'widths':dict(collections.Counter(len(r) for r in t.get('data',[]))),'title':t.get('title')} for i,t in enumerate(tables)]
   o.update(content_date=d.get('date'),date_identity_pass=d.get('date')==c['期間'].replace('-',''),tables=shape)
   try:o['parser_result']=audit_rows(b,{'source':src,'category':'margin'});o['status']='PARTIAL_CHECK_ONLY';o['unknown']=o['parser_result']['unverified']+['historical full population and PIT']
   except Exception as e:o.update(status='CONTENT_SCHEMA_FAIL',error=type(e).__name__+': '+str(e))
  elif src=='MOPS':
   s=b.decode('utf-8-sig');doc=html.fromstring(s);cells=[' '.join(x.text_content().split()) for x in doc.xpath('//td|//th')];codes=sorted({re.match(r'^(\d{4})\s*[^\d\s]',v).group(1) for v in cells if re.match(r'^(\d{4})\s*[^\d\s]',v)})
   o.update(parser_result=mops_html_evidence(s),table_count=len(doc.xpath('//table')),company_codes_in_headers=codes,period_evidence_found=bool(re.search(r'2001[年/.-]0?3|90年.*[第]?1季|090[年/.-]0?3',doc.text_content())),financial_numeric_cells=sum(bool(re.fullmatch(r'[+-]?[0-9][0-9,.]*',v)) for v in cells),status='CONTENT_INCOMPLETE',unknown=['original report period proof','full expected company/account universe','financial identities and announcement PIT'])
  elif src=='TAIFEX':
   o.update(parser_result=validate(b,{'kind':'annual','start':'2000-01-01','end':'2000-12-31'}),status='LIMITED_CHECK_PASS',unknown=['all required products/sessions/dates','all numeric rules','PIT'])
  elif src=='TDCC':
   rows=validate_history(b,c['期間'].replace('-',''),c['代碼']);o.update(parsed_rows=rows,date_identity_pass=True,code_identity_pass=True,status='LIMITED_CHECK_PASS',unknown=['historical instrument applicability','complete bin totals/rounding contract','PIT'])
  elif src=='NDC':
   d=json.loads(b);archive=(ROOT/'real_sample/containers/NDC_SOURCE.xlsx').read_bytes();o['archive_sha_match']=hashlib.sha256(archive).hexdigest()==d['source_archive']['sha256'];tables=parse_bundle(archive);regen=month_payload(tables,d['month'],d['source_archive']);o.update(derived_cells_match_native_archive=regen['tables']==d['tables'] and regen['gaps']==d['gaps'],tables=len(d['tables']),gaps=d['gaps'],cell_count=sum(len(t['cells']) for t in d['tables']),status='SOURCE_PERIOD_LIMITATION',unknown=['series applicability evidence','numeric economic interpretation','historical vintage PIT'])
 except Exception as e:o.update(status='PARSER_FAIL',error=type(e).__name__+': '+str(e))
 results.append(o)
(ROOT/'real_sample/sample_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
