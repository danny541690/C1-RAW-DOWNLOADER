import unittest,pathlib,json,hashlib,csv,gzip
R=pathlib.Path(__file__).resolve().parents[2]/'final'
class BaselineIntegrity(unittest.TestCase):
 def test_source_gzip_hashes_match_published_manifest(self):
  m=json.load(open(R/'manifest.json'))
  for p in (R/'units').glob('*.gz'):
   k='units/'+p.name;self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),m[k]['sha256'])
 def test_full_register_has_unique_tasks_and_reconciles_counts(self):
  ids=set();down=notdown=quality=0
  for p in (R/'units').glob('*.gz'):
   with gzip.open(p,'rt',encoding='utf-8-sig',newline='') as f:
    for u in csv.DictReader(f):
     self.assertNotIn(u['任務ID'],ids);ids.add(u['任務ID']);down+=int(u['已下載']);notdown+=int(u['未下載']);quality+=int(u['明列品質問題'])
  self.assertEqual((len(ids),down,notdown,quality),(337023,99700,237323,28546));self.assertEqual(down+notdown,len(ids))
 def test_live_baseline_event_journal_unchanged_empty(self):
  with open(R/'repair_events.csv',encoding='utf-8-sig') as f:self.assertEqual(list(csv.DictReader(f)),[])
